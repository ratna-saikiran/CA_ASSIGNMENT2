#include "hpca/hello_object.hh"
#include "debug/MATRIX.hh"
#include "debug/RESULT.hh"
#include <iostream>
using namespace std;
HelloObject::HelloObject(HelloObjectParams *params): SimObject(params){
        
        int matr[3][3] ={{2,3,4},{5,6,8},{1,7,9}};
        int matr1[3][3]={{2,3,4},{5,6,8},{1,7,9}};
        float det=0;
        //int a =1;
        //int b=4;
       

        //finding det
        for(int d =0;d<3;d++){
        	det=det+(matr[0][d] * (matr[1][(d+1)%3] * matr[2][(d+2)%3] - matr[1][(d+2)%3] * matr[2][(d+1)%3]));
       }
//        finding inverse of the matrix

        for(int i=0;i<3;i++){
        	for(int j=0;j<3;j++){
        		matr1[i][j]=((matr[(j+1)%3][(i+1)%3] * matr[(j+2)%3][(i+2)%3]) - (matr[(j+1)%3][(i+2)%3] * matr[(j+2)%3][(i+1)%3]))/ det;
        	}
        }
        for(int d =0;d<3;d++){
            det=det+(matr1[0][d] * (matr1[1][(d+1)%3] * matr1[2][(d+2)%3] - matr1[1][(d+2)%3] * matr1[2][(d+1)%3]));
       }
       //output the rsult
       if(DTRACE(MATRIX)){
        cout << "size of the array 3*3"<<"\n";
        for(int y=0;y<3;y++){
            for(int y1=0;y1<3;y1++){
                cout << matr[y][y1] << " \n "[y1==2];
            }
        }

       }
       if(DTRACE(RESULT)){
       // std::cout << "size of the array 3*3" << std::endl;
        for(int y=0;y<3;y++){
            for(int y1=0;y1<3;y1++){
                cout << matr1[y][y1] << " \n "[y1==2];
            }
        }

       }
       

       



        
}
HelloObject *
HelloObjectParams::create(){

    return new HelloObject(this);
}
