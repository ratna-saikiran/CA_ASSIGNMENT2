This package consists of 5 file 
1.HelloObject.py
This script is a python class for our SimObject ,this script has parameters for Simobject by which 
can be controlled by python config files ,Here we created a HelloObject class where we passed the SimObject 


2.hello_object.hh
3.hello_object.cc


in this c++ file we instantiated the 3*3 matrix and calculated the inverse of the matrix of it
and added debug flags like "MATRIX" which prints the starting matrix and size of the matrix
and debug flag like "RESULT " which prints the inverse of the matrix 

4.Sconscript ;
added all debug flags and source and SimObject

hello1.py
this is the configuration script here we instantiated root and imported all m5 objects 
and started simulation 


