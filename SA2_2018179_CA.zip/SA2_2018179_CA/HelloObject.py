from m5.params import *
from m5.SimObject import SimObject
class HelloObject(SimObject):

    type='HelloObject'
    cxx_header="hpca/hello_object.hh"
